document.getElementById("dream-meanings-btn").addEventListener("click", function() {
  window.location.href = "dream_meanings.html";
});

document.getElementById("back-btn").addEventListener("click", function() {
  window.location.href = "index.html"; 
});
